<?php
class DATABASE_CONFIG {
	
	public $timeout = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'root',
		'password' => 'zubayer',
		'database' => 'timeout'
	);
	
	public $blog = array(
			'datasource' => 'Database/Mysql',
			'persistent' => false,
			'host' => 'localhost',
			'login' => 'root',
			'password' => 'zubayer',
			'database' => 'blog'
	);

	public $ecommerce = array(
			'datasource' => 'Database/Mysql',
			'persistent' => false,
			'host' => 'localhost',
			'login' => 'root',
			'password' => 'zubayer',
			'database' => 'ecommerce'
	);
	
	public $default = array(
		'datasource' => 'Database/Mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'root',
		'password' => 'zubayer',
		'database' => 'cms'
	);
	
	
	
	
	
}
