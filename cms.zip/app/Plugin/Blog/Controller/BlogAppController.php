<?php

App::uses('AppController', 'Controller');

class BlogAppController extends AppController {

}
