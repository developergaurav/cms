<?php

App::uses('AppModel', 'Model');

class BlogAppModel extends AppModel {

}
