<?php
class EcommerceUploaderComponent extends UploaderComponent {

	public function get_web_root(){
		return WWW_ROOT. DS."Ecommerce".DS ;
	}
}


