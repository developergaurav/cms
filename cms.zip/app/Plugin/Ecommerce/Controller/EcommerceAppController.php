<?php

App::uses('AppController', 'Controller');

class EcommerceAppController extends AppController {
	
}
