<?php

App::uses('AppModel', 'Model');

class EcommerceAppModel extends AppModel {

}
