<?php

App::uses('AppController', 'Controller');

class TimeoutAppController extends AppController {

}
