<?php

App::uses('AppModel', 'Model');

class TimeoutAppModel extends AppModel {

}
